// التنقل بين الصفحات
document.getElementById("searchOption").addEventListener("click", function() {
    document.getElementById("page1").style.display = "none";
    document.getElementById("searchPage").style.display = "block";
});

document.getElementById("sellerOption").addEventListener("click", function() {
    document.getElementById("page1").style.display = "none";
    document.getElementById("sellerPage").style.display = "block";
});

// التنقل بين "سلعة أو منتج" و "خدمة"
document.getElementById("productOption").addEventListener("click", function() {
    document.getElementById("searchPage").style.display = "none";
    document.getElementById("productPage").style.display = "block";
});

document.getElementById("serviceOption").addEventListener("click", function() {
    document.getElementById("searchPage").style.display = "none";
    document.getElementById("servicePage").style.display = "block";
});

// تنفيذ البحث في صفحات المنتج والخدمة
document.querySelectorAll("form button").forEach(function(button) {
    button.addEventListener("click", function(event) {
        event.preventDefault();
        alert("تم إرسال البيانات بنجاح.");
    });
});

// التسجيل للبائع
document.querySelector("#sellerPage form button").addEventListener("click", function(event) {
    event.preventDefault();
    alert("تم التسجيل بنجاح.");
});
